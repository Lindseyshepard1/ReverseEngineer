﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WinterReverse.Models
{
    public class TicketRepository
    {

        public void GetTicketsByResortID(int ResortID)
        {

        }

        public void GetAllTickets()
        {

        }

        public void GetTicketByResortIDTicketType(int ResortID, int TicketTypeID)
        {

        }
    }
}
