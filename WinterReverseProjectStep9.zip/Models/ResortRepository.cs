﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WinterReverse.Models
{
    public class ResortRepository
    {
        public void GetResortByID(int ResortID)
        {

        }

        public void GetAllResorts()
        {

        }

        public void GetResortsByZip(string Zip)
        {

        }

        public void GetResortsByState(string Zip)
        {

        }
    }
}
